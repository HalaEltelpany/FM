# -*- coding: utf-8 -*-
from odoo import models, fields

class FmGatePass(models.Model):
    _name = 'fm.gate.pass'
    _description = 'Security Gate Pass / Visitor Permit'
    _order = 'create_date desc'
    _inherit = ['mail.thread']

    name = fields.Char(string='رقم التصريح (Pass Number)', required=True, default='New')
    unit_id = fields.Many2one('fm.unit', string='الوحدة (Unit)', required=True)
    visitor_name = fields.Char(string='اسم الزائر (Visitor Name)', required=True)
    visitor_car_plate = fields.Char(string='لوحة السيارة (Car Plate)')
    visit_date = fields.Date(string='تاريخ الزيارة (Visit Date)', required=True)
    visit_time_from = fields.Float(string='من الساعة (From)')
    visit_time_to = fields.Float(string='حتى الساعة (To)')
    pass_type = fields.Selection([
        ('visitor', 'زيارة عادية (Visitor)'),
        ('delivery', 'توصيل طلب (Delivery)'),
        ('contractor', 'مقاول/فني (Contractor)'),
        ('family', 'فرد أسرة (Family)'),
    ], string='نوع التصريح (Pass Type)', default='visitor', required=True)
    state = fields.Selection([
        ('pending', 'في الانتظار (Pending)'),
        ('approved', 'موافق عليه (Approved)'),
        ('used', 'تم استخدامه (Used)'),
        ('expired', 'منتهي الصلاحية (Expired)'),
    ], string='الحالة (Status)', default='pending', tracking=True)
    qr_code = fields.Char(string='QR Code')
    notes = fields.Text(string='ملاحظات (Notes)')
