# -*- coding: utf-8 -*-
from odoo import models, fields

class FmBooking(models.Model):
    _name = 'fm.booking'
    _description = 'Sports & Amenities Booking'
    _order = 'booking_date desc'
    _inherit = ['mail.thread']

    name = fields.Char(string='رقم الحجز (Booking Ref)', required=True, default='New')
    unit_id = fields.Many2one('fm.unit', string='الوحدة (Unit)', required=True)
    partner_id = fields.Many2one('res.partner', string='المالك / الساكن (Owner/Tenant)')
    activity_type = fields.Selection([
        ('padel', 'ملعب بادل تنس (Padel Tennis)'),
        ('football', 'ملعب كرة قدم (Football)'),
        ('swimming', 'حمام سباحة (Swimming Pool)'),
        ('gym', 'صالة رياضية (Gym)'),
        ('beach', 'شاطئ خاص (Private Beach)'),
        ('clubhouse', 'نادي اجتماعي (Clubhouse)'),
    ], string='نوع النشاط (Activity)', required=True, default='padel')
    booking_date = fields.Date(string='تاريخ الحجز (Date)', required=True)
    time_slot = fields.Selection([
        ('04:00-05:00', '04:00 - 05:00'),
        ('05:00-06:00', '05:00 - 06:00'),
        ('06:00-07:00', '06:00 - 07:00'),
        ('07:00-08:00', '07:00 - 08:00'),
        ('08:00-09:00', '08:00 - 09:00'),
        ('17:00-18:00', '17:00 - 18:00'),
        ('18:00-19:00', '18:00 - 19:00'),
        ('19:00-20:00', '19:00 - 20:00'),
        ('20:00-21:00', '20:00 - 21:00'),
        ('21:00-22:00', '21:00 - 22:00'),
    ], string='الفترة الزمنية (Time Slot)', required=True)
    amount = fields.Float(string='القيمة ج.م (Amount EGP)')
    payment_method = fields.Selection([
        ('wallet', 'محفظة التطبيق (App Wallet)'),
        ('cash', 'كاش عند الاستقبال (Cash)'),
    ], string='طريقة الدفع (Payment)', default='wallet')
    state = fields.Selection([
        ('pending', 'في الانتظار (Pending)'),
        ('confirmed', 'مؤكد (Confirmed)'),
        ('cancelled', 'ملغي (Cancelled)'),
    ], string='الحالة (Status)', default='pending', tracking=True)
    notes = fields.Text(string='ملاحظات (Notes)')
