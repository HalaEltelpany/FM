# -*- coding: utf-8 -*-
from odoo import models, fields

class FmMeter(models.Model):
    _name = 'fm.meter'
    _description = 'Smart Utility Meter (Prepaid)'
    _order = 'unit_id asc'

    name = fields.Char(string='رقم العداد (Meter Number)', required=True)
    unit_id = fields.Many2one('fm.unit', string='الوحدة (Unit)', required=True, ondelete='cascade')
    meter_type = fields.Selection([
        ('electricity', 'كهرباء (Electricity)'),
        ('water', 'مياه (Water)'),
    ], string='نوع العداد (Meter Type)', required=True, default='electricity')
    current_balance = fields.Float(string='الرصيد الحالي ج.م (Balance EGP)', default=0.0)
    last_recharge = fields.Float(string='آخر شحن ج.م (Last Recharge EGP)')
    last_recharge_date = fields.Datetime(string='تاريخ آخر شحن (Last Recharge Date)')
    iot_connected = fields.Boolean(string='متصل بـ IoT (IoT Connected)', default=True)
    state = fields.Selection([
        ('active', 'نشط (Active)'),
        ('low', 'رصيد منخفض (Low Balance)'),
        ('disconnected', 'غير متصل (Disconnected)'),
    ], string='الحالة (Status)', default='active')
