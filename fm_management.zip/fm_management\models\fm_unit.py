# -*- coding: utf-8 -*-
from odoo import models, fields, api

class FmUnit(models.Model):
    _name = 'fm.unit'
    _description = 'Property Unit & Maintenance Deposit'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name asc'

    name = fields.Char(string='رقم الوحدة (Unit Number)', required=True, tracking=True)
    partner_id = fields.Many2one('res.partner', string='مالك الوحدة (Owner)', required=True, tracking=True)
    unit_type = fields.Selection([
        ('residential', 'وحدة سكنية (Residential)'),
        ('commercial', 'وحدة تجارية (Commercial)'),
        ('villa', 'فيلا مستقلة (Villa)'),
        ('chalet', 'شاليه ساحلي (Chalet)')
    ], string='نوع الوحدة (Unit Type)', default='residential', required=True)

    # Financial & Installments Summary
    total_price = fields.Float(string='إجمالي سعر الوحدة (Total Price)', default=4500000.0)
    paid_amount = fields.Float(string='المبلغ المسدد (Paid Amount)', default=3150000.0)
    remaining_amount = fields.Float(string='المتبقي بأقساط (Remaining)', compute='_compute_financials', store=True)
    payment_progress = fields.Float(string='نسبة السداد % (Progress)', compute='_compute_financials', store=True)

    # Maintenance Deposit & Variance
    deposit_balance = fields.Float(string='رصيد الوديعة الأصلية (Deposit Balance)', default=150000.0)
    annual_yield = fields.Float(string='عوائد الاستثمار السنوية (Annual Yield)', default=18500.0)
    operating_cost_share = fields.Float(string='حصة التشغيل (Operating Costs)', default=22400.0)
    net_maintenance_variance = fields.Float(string='صافي فروق الصيانة (Net Variance)', default=3900.0)

    # Relations
    installment_ids = fields.One2many('fm.installment', 'unit_id', string='جدول الأقساط (Installments)')
    meter_ids = fields.One2many('fm.meter', 'unit_id', string='العدادات الذكية (Meters)')
    gate_pass_ids = fields.One2many('fm.gate.pass', 'unit_id', string='تصاريح الأمن (Gate Passes)')
    booking_ids = fields.One2many('fm.booking', 'unit_id', string='حجوزات الملاعب (Bookings)')

    @api.depends('total_price', 'paid_amount')
    def _compute_financials(self):
        for rec in self:
            rec.remaining_amount = rec.total_price - rec.paid_amount
            if rec.total_price > 0:
                rec.payment_progress = (rec.paid_amount / rec.total_price) * 100.0
            else:
                rec.payment_progress = 0.0
