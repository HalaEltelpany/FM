# -*- coding: utf-8 -*-
from odoo import models, fields

class FmInstallment(models.Model):
    _name = 'fm.installment'
    _description = 'Property Financial Installment'
    _order = 'due_date asc'

    name = fields.Char(string='كود القسط (Installment Code)', required=True)
    unit_id = fields.Many2one('fm.unit', string='الوحدة (Unit)', required=True, ondelete='cascade')
    sequence = fields.Integer(string='رقم القسط (No.)', default=1)
    amount = fields.Float(string='قيمة القسط (Amount)', required=True)
    due_date = fields.Date(string='تاريخ الاستحقاق (Due Date)', required=True)
    state = fields.Selection([
        ('paid', 'مسدد (Paid)'),
        ('due', 'قادم (Due)'),
        ('overdue', 'متأخر (Overdue)'),
    ], string='الحالة (Status)', default='due', required=True)
    payment_date = fields.Date(string='تاريخ السداد الفعلي (Payment Date)')
    notes = fields.Text(string='ملاحظات (Notes)')
